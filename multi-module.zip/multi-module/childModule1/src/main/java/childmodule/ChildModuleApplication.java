package childmodule;

import childModule.entity.TestModuleTwo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Project Name: multi-module
 * File Name: ChildModuleApplication
 * Package Name: PACKAGE_NAME
 * Date: 2019/7/9 15:48
 * Copyright (c) 2019, huafon Chuangxiang Co., Ltd. All Rights Reserved.
 */

@SpringBootApplication
public class ChildModuleApplication {
    public static void main(String[] args) {
        SpringApplication.run(ChildModuleApplication.class, args);

        TestModuleTwo testModuleTwo = new TestModuleTwo();
        System.out.println(testModuleTwo.getMsg());
    }
}
