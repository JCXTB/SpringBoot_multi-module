/**
 * Project Name: multi-module
 * File Name: TestModuleOne
 * Package Name: childmodule.entity
 * Date: 2019/7/9 16:10
 * Copyright (c) 2019, huafon Chuangxiang Co., Ltd. All Rights Reserved.
 */
package childmodule.entity;

import childModule.entity.TestModuleTwo;

public class TestModuleOne {

}
