/**
 * Project Name: multi-module
 * File Name: TestModuleTwo
 * Package Name: childModule.entity
 * Date: 2019/7/9 16:08
 * Copyright (c) 2019, huafon Chuangxiang Co., Ltd. All Rights Reserved.
 */
package childModule.entity;

public class TestModuleTwo {
    private final String msg = "这里是 childModule2";

    public String getMsg(){
        return this.msg;
    }
}
